# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: JonathanAntonioModjewski / SamelaHostins  
Orientador: Simone  
Título: Sistema de Gerenciamento para Pessoas com MEI na Área de Estética  

## Atendimento Termo  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 70%  
Comentários: 
Está bem encaminhado.  
Colocaram uma observação no final mencionando que as tecnologias serão estudadas em 2024-2, uma vez que o TCC2 em si será desenvolvido em 2025-1.  

[x] interagindo com o orientador:  
[x] cabeçalho:  
[ ] título: pegar do Termo  
[x] contextualização:  
[x] objetivos:  
[x] revisão bibliográfica
  Falta descrever o assunto 2.1.4  
[x] correlato 1:  
[x] correlato 2:  
[x] correlato 3:  
[x] quadro comparativo:  
[x] justificativa:  
[x] metodologia:  
[x] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
