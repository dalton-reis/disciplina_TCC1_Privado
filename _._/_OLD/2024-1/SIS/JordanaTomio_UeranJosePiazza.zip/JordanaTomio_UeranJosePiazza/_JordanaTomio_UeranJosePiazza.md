# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: JordanaTomio - UeranJosePiazza  
Orientador: Andreza  
Título: Furbot na Terra da IA: Construção de um Jogo Interativo para o Ensino Introdutório de Inteligência Artificial para Crianças  

## Atendimento Termo  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 80%  
Comentários: bem encaminhado. Falta ajustes enviados pela orientadora.    
[x] interagindo com o orientador:  
[x] cabeçalho:  
[x] título:  
[..] contextualização: incluir um parágrafo sobre o FURBOT  
[x] objetivos:  
[x] revisão bibliográfica
[x] correlato 1:  
[x] correlato 2:  
[x] correlato 3:  
[x] quadro comparativo:  
[x] justificativa:  
[x] metodologia:  
[x] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
