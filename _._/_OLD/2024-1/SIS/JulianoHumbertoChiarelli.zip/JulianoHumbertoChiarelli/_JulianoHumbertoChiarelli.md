# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: JulianoHumbertoChiarelli  
Orientador: Danton  
Título: Análise de Múltiplas IAs Sobre o Pefil dos Compradores de Uma Loja de Esportes  

## Atendimento Termo  

[2024-03-08_EMail.pdf](2024-03-08_EMail.pdf)  
[2024-03-11_Danton_EMail.pdf](2024-03-11_Danton_EMail.pdf)  
[2024-03-11_Andreza_EMail.pdf](2024-03-11_Andreza_EMail.pdf)  
[2024-03-18_Danton_EMail.pdf](2024-03-18_Danton_EMail.pdf)  
[2024-03-25_Danton_Teams.pdf](2024-03-25_Danton_Teams.pdf)  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

## 2024-04-23 - 20:29

MS-Teams: Boa noite, meu pré projeto está pronto ok, vou entregar pro orientador hoje  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 20%  
Comentários:  
Está no caminho certo mas precisa acelerar, pois está atrasado em relação ao cronograma.  
Demorou para fechar assunto/orientador.  
ATENÇÃO: está atrasado em relação ao cronograma.  

[x] interagindo com o orientador:  
[ ] cabeçalho: pegar do Termo.  
[ ] título: pegar do Termo.  
[x] contextualização: descreveu mas tem textos com afirmações sem usar citações.  
[x] objetivos:  
[ ] revisão bibliográfica: inicio (1 parágrafo o 2.1.1).  
[ ] correlato 1:  
[ ] correlato 2:  
[ ] correlato 3:  
[ ] quadro comparativo:  
[ ] justificativa:  
[ ] metodologia:  
[ ] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
