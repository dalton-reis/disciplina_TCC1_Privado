# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: GuilhermeSouzaDosSantos / JennyferAraujo  
Orientador:  
Título:  

## Atendimento Termo  

### 2024-03-04 - 21:05

Comentaram que pretendem fazer um dupla.  
O "GuilhermeSouzaDosSantos" vai se inscrever na disciplina de TCC1 ainda.  

TCC Inovação  
Especialista  
Detecção de problemas cardíacos  
TCC Aurelio: CARDIOREADER: Sistema de Identificação de Batimentos Cardíacos  
<https://www.furb.br/dsc/arquivos/tccs/monografias/2013_2_anderson-mordhorst_monografia.pdf>  
Apple: iPhone, Apple / Mi Band -> dados  

Comentei sobre o TCC da EduardaEngels do prof. Aurélio  

Apresentei a ideia do uso do Scanner 3D para a Total Healt  
[2024-03-07_MsTeams.pdf](2024-03-07_MsTeams.pdf)  

## 2024-03-12 - 10:39

Jader: (47) 99676‑5373  

Oi Jader, sou o prof. Dalton do Departamento de Sistemas e Computação (DSC) da FURB.  
Já conversamos sobre o agendamento da RetroSC aqui na FURB (na verdade estais conversando com o prof. Aurélio).  
Bom, tentado ser breve ...  
Nos aqui do DSC temos uma peças antigas de equipamentos da computação e pretendemos criar uma exposição fixa e permanente nos corredores dos nossos laboratórios de computação. Quem está adquirindo/organizando/etc. essas peças são os professores Miguel, Péricas e Aurélio.  
Um tempo atrás pensamos em desenvolver um aplicativo móvel para auxiliar o visitante conhecer essa exposição.  
Este semestre apareceu dois alunos do curso de Sistemas de Informação que gostaram da ideia de desenvolver esse aplicativo para o seu Trabalho de Conclusão de Curso (TCC). No caso eles fazem o projeto agora (2024-1) e desenvolvem o TCC em 2024-2.  
Bom, neste projeto temos além do orientador (no caso eu), também que indicar um mentor (no caso do TCC do tipo Inovação). O papel deste mentor no projeto e TCC e dá apoio nas dúvidas e ideias para o desenvolvimento.  
Até poderíamos colocar como mentor neste TCC um dos professores citados acima, mas gostaria de convidar você, ou alquém do grupo do RetroSC.  
A ideia é o que o mentor possa ser consultado para tirar dúvidas e ideias sobre o cenário do problema, no caso a exposição de peças antigas da computação. Geralmente se tem umas 2 conversas (que podem ser remotas) no projeto, e mais uma duas no TCC.  
O que achas, poderias participar? Ou indicar alguém?  

Comentários:  
[Termo](Termo.pdf "Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado:  
Comentários:  
[ ] interagindo com o orientador:  
[ ] cabeçalho:  
[ ] título:  
[ ] contextualização:  
[ ] objetivos:  
[ ] revisão bibliográfica
[ ] correlato 1:  
[ ] correlato 2:  
[ ] correlato 3:  
[ ] quadro comparativo:  
[ ] justificativa:  
[ ] metodologia:  
[ ] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
