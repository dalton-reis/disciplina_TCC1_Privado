# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: EduardoCampestrini  
Orientador: Luciana  
Título: Sistema para Gestão de Audiometrias  

## Atendimento Termo  

### 2024-03-05 - 10:24

Consulta respondida pelo MS-Teams.  
[2024-03-05_EMail.pdf](2024-03-05_EMail.pdf)  
[2024-03-06_EMail.pdf](2024-03-06_EMail.pdf)  
[2024-03-07_EMail.pdf](2024-03-07_EMail.pdf)  
[2024-03-11_EMail.pdf](2024-03-11_EMail.pdf)  
[2024-03-22_EMail.pdf](2024-03-22_EMail.pdf)  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

**ATENÇÃO**: chamei para conversar sobre o pré-projeto mas não retornou.  

Percentual estimado: 60%  
Comentários: fez bastante partes mas falta um retorno da orientadora.  
[ ] interagindo com o orientador:  
[x] cabeçalho:  
[x] título:  
[x] contextualização:  
[x] objetivos:  
[x] revisão bibliográfica
[x] correlato 1:  
[x] correlato 2:  
[x] correlato 3:  
[x] quadro comparativo:  
[x] justificativa:  
[x] metodologia:  
[x] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
