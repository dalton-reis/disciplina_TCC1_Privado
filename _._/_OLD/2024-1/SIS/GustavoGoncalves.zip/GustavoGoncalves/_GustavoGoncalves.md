# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: GustavoGoncalves  
Orientador: Danton  
Título: NutriVerifica: Uma Abordagem Tecnológica para Facilitar Escolhas Alimentares Conscientes em Pessoas com Restrições e Preferências Alimentares  

## Atendimento Termo  

### 2024-02-29 - 11:47

[2024-02-29_EMail.pdf](2024-02-29_EMail.pdf)  
[2024-03-04_EMail.pdf](2024-03-04_EMail.pdf)  
[2024-03-07_MsTeams.pdf](2024-03-07_MsTeams.pdf)  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

## 2024-04-08 - 19:05

Estava na empresa trabalhando e não tinha como mostrar o pré-projeto.  
Pedi para enviar uma copia para poder olhar o andamento do pré-projeto mas disse que só tinha o texto no seu PC em casa. O que me assustou MUITO, pois não se ter uma copia deste documento na nuvem é muito "perigoso", para não dizer estranho. Disse que ia enviar amanhã cedo.  
Bom, forte preocupação se vai conseguir entregar o pré-projeto no prazo definido no nosso cronograma.  

Percentual estimado:  
Comentários:  
[ ] interagindo com o orientador:  
[ ] cabeçalho:  
[ ] título:  
[ ] contextualização:  
[ ] objetivos:  
[ ] revisão bibliográfica
[ ] correlato 1:  
[ ] correlato 2:  
[ ] correlato 3:  
[ ] quadro comparativo:  
[ ] justificativa:  
[ ] metodologia:  
[ ] referências:  

## 2024-04-22 - 19:18

Boa noite professor, meu TCC está em cerca de 70% completo.  
Falta fazer os correlatos, especificar mais algumas questões da contextualização e Bases teóricas, bem como alguns ajustes nas metodologias.  
Creio que eu consiga entregar até o dia 29/04.  

## 2024-04-29 - 09:23

[2024-04-29_EMail.pdf](2024-04-29_EMail.pdf)  

[2024-05-03_EMail.pdf](2024-05-03_EMail.pdf)  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
