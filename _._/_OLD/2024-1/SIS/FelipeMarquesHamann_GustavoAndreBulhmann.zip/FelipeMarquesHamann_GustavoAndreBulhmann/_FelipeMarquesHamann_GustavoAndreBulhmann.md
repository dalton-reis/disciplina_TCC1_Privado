# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: FelipeMarquesHamann  
Orientador: Simone  
Título: Controle de Serviços e Gerenciamento de Oficinas Mecânicas  

## Atendimento Termo  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

## 2024-04-15 - 20:00

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 99%  
Comentários: quase pronto, nos finais.  
[x] interagindo com o orientador:  
[x] cabeçalho:  
[x] título:  
[x] contextualização:  
[x] objetivos:  
[x] revisão bibliográfica
[x] correlato 1:  
[x] correlato 2:  
[x] correlato 3:  
[x] quadro comparativo:  
[x] justificativa:  
[x] metodologia:  
[x] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
