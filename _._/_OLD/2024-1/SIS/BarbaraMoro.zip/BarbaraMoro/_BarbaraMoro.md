# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: BarbaraMoro  
Orientador: Simone  
Título: Desenvolvimento de um Sistema de Informações Integrado para Pequenas Empresas: Uma Solução para Gerenciamento de Clientes e Fluxo de Caixa  

## Atendimento Termo  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

## 2024-04-15 - 19:16

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 99%  
Comentários: revisando detalhes finais, pronto para entregar.  
[x] interagindo com o orientador:  
[x] cabeçalho:  
[x] título:  
[x] contextualização:  
[x] objetivos:  
[x] revisão bibliográfica
[x] correlato 1:  
[x] correlato 2:  
[x] correlato 3:  
[x] quadro comparativo:  
[x] justificativa:  
[x] metodologia:  
[x] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
