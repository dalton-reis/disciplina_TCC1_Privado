# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: GabrielKrzizanowski - LucasEduardoDeCarvalho  
Orientador: Aurélio  
Título: MicroCell - Aplicativo para contagem de células por quadrante em fotos microscópicas  

## Atendimento Termo  

[2024-03-11_EMail.pdf](2024-03-11_EMail.pdf)  

[2024-04-08_EMail.pdf](2024-04-08_EMail.pdf)  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

## 2024-04-15 - 20:34

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 50%  
Comentários: teve um atraso até conseguir conversar com a coorientadora.  
[ ] interagindo com o orientador:  
[x] cabeçalho:  
[x] título: alterou  
[x] contextualização:  
[ ] objetivos:  
[x] revisão bibliográfica, podeira aumentar a subseção 2.1.2  
[ ] correlato 1:  
[ ] correlato 2:  
[ ] correlato 3:  
[ ] quadro comparativo:  
[ ] justificativa:  
[ ] metodologia:  
[ ] referências:  

## 2024-04-22 - 19:18

Olá professor, boa noite! Projeto está em 92%, recebemos o retorno final do prof Aurélio hoje para corrigir alguns pontos, iremos fazer a correção, encaminhar para ele novamente e aí liberamos. Previsão de envio até quinta, aguardando apenas a revisão final do professor Aurélio.  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
