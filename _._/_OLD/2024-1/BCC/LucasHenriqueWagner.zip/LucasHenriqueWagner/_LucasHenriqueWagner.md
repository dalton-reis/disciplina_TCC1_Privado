# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: Lucas Henrique Wagner  
Orientador: Aurelio  
Título: Modelo de Sistema Multiagente para análise de impacto do tráfego na Cidade de Blumenau  

## Atendimento Termo  

## 2024-02-27 - 21:15

Lucas -> Gostaria após o intervalo conversar sobre os temas e orientador para o TCC  
Dalton -> Oi, posso te chamar para conversar?  
.. sem reposta  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 90%  
Comentários: fazendo ajustes finais.  
[x] interagindo com o orientador:  
[x] cabeçalho:  
[x] título:  
[x] introdução:  
[x] objetivos:  
[x] correlato 1:  
[x] correlato 2:  
[x] correlato 3:  
[x] justificativa:  
[x] quadro comparativo:  
[x] requisitos:  
[x] metodologia:  
[x] cronograma:  
[x] revisão bibliográfica:  
[ ] referências: falta fazer  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
