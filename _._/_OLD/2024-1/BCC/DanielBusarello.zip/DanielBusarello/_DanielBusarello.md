# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: DanielBusarello  
Orientador: Luciana  
Título: Aplicação do Hl7® Fhir para Interoperabilidade de Dispositivos e Sistemas de Informação de Saúde Utilizando Microsserviços  

## Atendimento Termo  

[2024-03-07_EMail.pdf](2024-03-07_EMail.pdf)  
[2024-03-13_EMail.pdf](2024-03-13_EMail.pdf)  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 25%  
Comentários: precisa acelerar pois está atrasado.  
[X] interagindo com o orientador:  
[ ] cabeçalho:  
[ ] título:  
[ ] introdução:  
[ ] objetivos:  
[ ] correlato 1:  
[ ] correlato 2:  
[ ] correlato 3:  
[ ] justificativa:  
[ ] quadro comparativo:  
[X] requisitos: fez no outro documento  
[ ] metodologia:  
[ ] cronograma:  
[ ] revisão bibliográfica:  
[ ] referências:  

## 2024-04-23 - 20:35

MS-Teams: Boa noite professor, não vou conseguir entregar o pré-projeto hoje. Consegui avançar bastante desde a última conversa, está 75% pronto, não obtive retorno da prof. Luciana quanto aos trabalhos correlatos ainda, enviei 2 e-mails para ela. Porém, mesmo sem a resposta, já iniciei a comparação dos trabalhos com o meu. Acredito que se ela aprovar, até dia 30/04 estarei finalizando.  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
