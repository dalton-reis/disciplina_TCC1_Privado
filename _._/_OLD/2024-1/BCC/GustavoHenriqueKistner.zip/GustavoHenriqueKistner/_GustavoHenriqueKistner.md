# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: GustavoHenriqueKistner  
Orientador: Andreza  
Co-Orientador: Júlio Cesar de Souza Júnior  
Título: Plataforma de Comunicação para o Registro de Resgate e Reabilitação de Animais Silvestres  

## Atendimento Termo  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 70%  
Comentários: trabalhando nos ajustes da orientadora.    
[x] interagindo com o orientador:  
[x] cabeçalho:  
[x] título:  
[x] introdução:  
[x] objetivos:  
[x] correlato 1:  
[x] correlato 2:  
[x] correlato 3:  
[x] justificativa:  
[x] quadro comparativo:  
[x] requisitos:  
[x] metodologia:  
[x] cronograma:  
[ ] revisão bibliográfica: falta fazer  
[ ] referências: fez 3, masi tem várias outras para fazer.  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
