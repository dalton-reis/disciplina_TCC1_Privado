# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: ViniciusPereiraForte  
Orientador: Valdameri  
Título: Estudo de Caso Aplicando a Extensão Espacial Postgis para PostgreSQL  

## Atendimento Termo  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

**ATENÇÃO**: chamei no chart do MS-Teams no dia/horário agendado mas não respondeu.  

Percentual estimado:  
Comentários:  
[ ] interagindo com o orientador:  
[ ] cabeçalho:  
[ ] título:  
[ ] introdução:  
[ ] objetivos:  
[ ] correlato 1:  
[ ] correlato 2:  
[ ] correlato 3:  
[ ] justificativa:  
[ ] quadro comparativo:  
[ ] requisitos:  
[ ] metodologia:  
[ ] cronograma:  
[ ] revisão bibliográfica:  
[ ] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
