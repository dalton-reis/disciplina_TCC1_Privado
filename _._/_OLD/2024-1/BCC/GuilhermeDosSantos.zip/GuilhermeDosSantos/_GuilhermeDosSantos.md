# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: GuilhermeDosSantos  
Orientador: Pericas  
Título: Aplicativo Colaborativo para Gerenciamento de Tarefas  

## Atendimento Termo  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 85%  
Fez semestre passado TCC1.  
Me parece que tem poucas referências, mas ok.  
Ainda tem ajustes pequenos de formatação e ABNT.  

Comentários:  
[X] interagindo com o orientador:  
[X] cabeçalho:  
[X] título:  
[X] introdução:  
[X] objetivos:  
[X] correlato 1:  
[X] correlato 2:  
[X] correlato 3:  
[X] justificativa:  
[X] quadro comparativo:  
[X] requisitos:  
[X] metodologia:  
[X] cronograma:  
[X] revisão bibliográfica:  
[X] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
