# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: SezioClenerNascimento  
Orientador: Miguel  
Título: Implementação da Máquina M++ em FPGA  

## Atendimento Termo  

[2024-03-13_EMail.pdf](2024-03-13_EMail.pdf)  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

## 2024-04-11 - 17:27

Atendi pessoalmente no LDTT e fiquei arrumando o formato do texto até as 18:25.  Reforcei que não olhei o texto em sei, só formatei, e que não olhei as citações e referências.  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 80%  
Comentários: já fez o TCC1 do semestre passado. Muitos erros de formatação. Deixei o Whats para agendar para ajudar a arrumar.

[ ] interagindo com o orientador:  
[ ] cabeçalho:  
[ ] título:  
[ ] introdução:  
[ ] objetivos:  
[ ] correlato 1:  
[ ] correlato 2:  
[ ] correlato 3:  
[ ] justificativa:  
[ ] quadro comparativo:  
[ ] requisitos:  
[ ] metodologia:  
[ ] cronograma:  
[ ] revisão bibliográfica:  
[ ] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
