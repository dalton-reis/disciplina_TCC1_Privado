# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: FranciscoJoseTeodoroDaLuz  
Orientador:  
Título:  

## Atendimento Termo  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 40%  
Comentários: precisa acelerar, está encaminhado, mas precisa acelerar.  
[X] interagindo com o orientador:  
[X] cabeçalho:  
[X] título:  
[ ] introdução:  
[ ] objetivos:  
[ ] correlato 1: descreveu  
[ ] correlato 2: descreveu  
[ ] correlato 3: tem, mas vai descrever  
[ ] justificativa:  
[ ] quadro comparativo:  
[ ] requisitos:  
[ ] metodologia:  
[ ] cronograma:  
[ ] revisão bibliográfica:  
[ ] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
