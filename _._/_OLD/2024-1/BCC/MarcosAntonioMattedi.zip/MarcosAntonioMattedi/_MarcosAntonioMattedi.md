# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: MarcosAntonioMattedi  
Orientador: Aurelio  
Título: Modelagem Baseada em Agente Aplicada ao Processo de Verticalização Urbana no Brasil  

## Atendimento Termo  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 70% 
Comentários:  
[X] interagindo com o orientador:  
[X] cabeçalho:  
[X] título:  
[X] introdução:  
[ ] objetivos:  
[X] correlato 1:  
[X] correlato 2:  
[X] correlato 3:  
[ ] justificativa:  
[ ] quadro comparativo:  
[ ] requisitos:  
[X] metodologia:  
[ ] cronograma:  
[ ] revisão bibliográfica:  
[ ] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
