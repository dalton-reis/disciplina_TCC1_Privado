# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: MatheusFelipeDaSilvaSychocki  
Orientador: Danton  
Título: Syspower Analyzer: Ferramenta de Medição do Custo Energético em Execuções de Rotinas Sistêmicas  

## Atendimento Termo  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 70%  
Comentários: está desenvolvendo.  
[x] interagindo com o orientador:  
[x] cabeçalho:  
[x] título:  
[x] introdução:  
[x] objetivos:  
[x] correlato 1:  
[x] correlato 2:  
[x] correlato 3:  
[x] justificativa:  
[x] quadro comparativo:  
[x] requisitos:  
[x] metodologia:  
[x] cronograma:  
[ ] revisão bibliográfica: não fez  
[ ] referências: falta fazer, mas vai aproveitar do semestre anterior (TCC1)  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
