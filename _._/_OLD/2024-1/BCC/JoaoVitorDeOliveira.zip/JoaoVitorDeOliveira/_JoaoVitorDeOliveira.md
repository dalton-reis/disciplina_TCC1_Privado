# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: JoaoVitorDeOliveira  
Orientador: Danton
Título: HyperMon  

## Atendimento Termo  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 60%  
Comentários:  
[x] interagindo com o orientador:  
[x] cabeçalho:  
[x] título:  
[x] introdução:  
[x] objetivos:  
[x] correlato 1:  
[x] correlato 2:  
[x] correlato 3:  
[x] justificativa:  
[x] quadro comparativo:  
[x] requisitos:  
[x] metodologia:  
[x] cronograma:  
[ ] revisão bibliográfica: fez um pouco. Tem subseções com só um parágrafo.  
[ ] referências: não fez.  

## 2024-04-23 - 20:33

MS-TEams: Boa noite professor, tudo certo? Meu pre projeto já foi encaminhado para o Danton, ainda nao recebi retorno.  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
