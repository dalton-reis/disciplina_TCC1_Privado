# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: MatheusFelipePasold  
Orientador: Valdameri  
Título: Estudo de Caso Utilizando Estruturas NoSQL em uma Aplicação para Organização de Competições Esportivas  

## Atendimento Termo  

[2024-03-07_MsTeams.pdf](2024-03-07_MsTeams.pdf)  

Comentários:  
[1_Termo](1_Termo.pdf "1_Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 15%  
Comentários: atrasado, precisa REALMENTE acelerar.  
  
[X] interagindo com o orientador:  
[ ] cabeçalho:  
[ ] título:  
[ ] introdução:  
[ ] objetivos:  
[X] correlato 1: parcialmente descrito  
[ ] correlato 2: já achou, mas não  
[ ] correlato 3:  já achou, mas vai substituir um  
[ ] justificativa:  
[ ] quadro comparativo:  
[ ] requisitos:  
[ ] metodologia:  
[ ] cronograma:  
[ ] revisão bibliográfica:  
[ ] referências:  

## 2024-04-23 - 20:32

MS-Teams: Acho que o Valdameri falou sobre o meu pré projeto. Mas vou ainda corrigir o que ele me apontou no que já está feito. 98% concluído.  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
