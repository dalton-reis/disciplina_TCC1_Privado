# Anotações das Reuniões Individuais  

![foto](foto.png "foto")  
Orientando: FelipeKriegerBuche  
Orientador: Dalton  
Título: ExpoFritz  

Curador do Exposição Científica Fritz Müller  
Sérgio Luiz Althoff  
99918-8967  
<https://www.furb.br/pt/noticias/sala-de-exposicao-fritz-muller-de-ciencias-naturais-abre-para-visitacao-em-marco>  

## Atendimento Termo  

### 2024-02-29 - 17:41

Conversamos no final da aula de RV.  
Assunto: aplicativo para o Museu da FURB.  
Vai usar Kotlin (Android).  

Material:  
<https://github.com/gcgfurb/tcc_JulioVicenteBrych/blob/master/tcc_bcc_2023_2_JulioVicenteBrych/Textos/tcc_bcc_2023_02_JulioVicenteBrych-VF.pdf>  
<https://github.com/gcgfurb/tcc_HenriqueDelegrego/blob/master/tcc_bcc_2023_1_HenriqueDelegrego/Textos/tcc_bcc_2023_1_HenriqueDelegrego-VF.pdf>  

Comentários:  
[Termo](Termo.pdf "Termo")  

### XXXX-XX-XX

## Atendimento Pré-Projeto  

[2_PreProjeto](2_PreProjeto.docx "2_PreProjeto")  

Percentual estimado: 15%  
Comentários: fez alguns esboços mas precisa acelerar bastante pois está um pouco atrasado.  
[ ] interagindo com o orientador:  
[ ] cabeçalho:  
[ ] título:  
[ ] introdução:  
[ ] objetivos:  
[ ] correlato 1:  
[ ] correlato 2:  
[ ] correlato 3:  
[ ] justificativa:  
[ ] quadro comparativo:  
[ ] requisitos:  
[ ] metodologia:  
[ ] cronograma:  
[ ] revisão bibliográfica:  
[ ] referências:  

## Atendimento Projeto  

Percentual estimado:  
Comentários:  
